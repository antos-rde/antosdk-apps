# libplotly
Built on top of d3.js and stack.gl, Plotly.js is a high-level, declarative charting library. plotly.js ships with over 40 chart types, including 3D charts, statistical graphs, and SVG maps.
plotly.js is free and open source and you can view the source, [report issues or contribute on GitHub](https://github.com/plotly/plotly.js).

This package is the AntOS wrapper of Plotly used as library for AntOS applications