# Preview

Image and PDF file viewer for AntOS

## Change logs
* v0.1.0-a: add depends on libpdfjs, user the default PDFJS viewer