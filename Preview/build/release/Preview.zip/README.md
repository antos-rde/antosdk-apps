# Preview

Image and PDF file viewer for AntOS

## Change logs
* v0.1.2-a: support AntOS v2.0.x
* v0.1.0-a: add depends on libpdfjs, user the default PDFJS viewer