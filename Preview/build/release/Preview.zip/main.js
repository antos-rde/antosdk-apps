(function() {
  // Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>

  // AnTOS Web desktop is is licensed under the GNU General Public
  // License v3.0, see the LICENCE file for more information

  // This program is free software: you can redistribute it and/or
  // modify it under the terms of the GNU General Public License as
  // published by the Free Software Foundation, either version 3 of 
  // the License, or (at your option) any later version.

  // This program is distributed in the hope that it will be useful,
  // but WITHOUT ANY WARRANTY; without even the implied warranty of
  // MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  // General Public License for more details.

  // You should have received a copy of the GNU General Public License
  //along with this program. If not, see https://www.gnu.org/licenses/.
  var Preview;

  Preview = class Preview extends this.OS.application.BaseApplication {
    constructor(args) {
      super("Preview", args);
    }

    main() {
      this.currfile = void 0;
      if (this.args && this.args.length > 0) {
        this.currfile = this.args[0].path.asFileHandle();
      }
      this.view = this.find("view");
      this.status = this.find("status");
      this.zoom = this.find("zoom");
      this.btreset = this.find("btreset");
      this.zoom.onvaluechange = (e) => {
        return this.setViewScale(e.data);
      };
      this.btreset.onbtclick = (e) => {
        this.zoom.value = 100;
        return this.setViewScale(100);
      };
      this.img = void 0;
      this.bindKey("ALT-O", () => {
        return this.actionFile(`${this.name}-Open`);
      });
      this.bindKey("CTRL-X", () => {
        return this.actionFile(`${this.name}-Close`);
      });
      this.zoom.max = 200;
      this.zoom.value = 100;
      return this.open(this.currfile);
    }

    open(file) {
      if (!file) {
        return;
      }
      if (this.currfile !== file) {
        this.currfile = file;
      }
      return file.onready().then(() => {
        file.info.size = (file.info.size / 1024).toFixed(2);
        return this.renderFile();
      }).catch((err) => {
        return this.error(__("File not found {0}", file.path), err);
      });
    }

    renderFile() {
      var mime;
      mime = this.currfile.info.mime;
      if (!mime) {
        return;
      }
      this.img = void 0;
      ($(this.view)).empty();
      this.zoom.value = 100;
      this.scheme.apptitle = this.currfile.info.name;
      if (mime.match(/^[^\/]+\/.*pdf.*/g)) {
        return this.renderPDF();
      } else if (mime.match(/image\/.*svg.*/g)) {
        return this.renderSVG();
      } else if (mime.match(/image\/.*/g)) {
        return this.renderImage();
      } else {
        return this.notify(__("Mime type {0} is not supported", file.info.mime));
      }
    }

    setStatus(t) {
      return ($(this.status)).html(t);
    }

    setViewScale(value) {
      var canvas, context, h, mime, scale, w;
      if (!this.currfile) {
        return;
      }
      mime = this.currfile.info.mime;
      scale = value / 100;
      if (mime.match(/image\/.*svg.*/g)) {
        return $($(this.view).children()[0]).css("width", `${Math.round(value)}%`).css("height", `${Math.round(value)}%`);
      } else if (mime.match(/image\/.*/g)) {
        if (!this.img) {
          return;
        }
        canvas = $(this.view).children()[0];
        context = canvas.getContext('2d');
        w = this.img.width * scale;
        h = this.img.height * scale;
        canvas.height = h;
        canvas.width = w;
        context.clearRect(0, 0, canvas.width, canvas.height);
        context.scale(scale, scale);
        return context.drawImage(this.img, 0, 0);
      }
    }

    renderPDF() {
      var frame;
      $(this.find("statcontainer")).hide();
      this.trigger("resize");
      ($(this.view)).attr("class", "pdf");
      frame = ($("<iframe/>")).css("width", "100%").css("height", "100%");
      ($(this.view)).append(frame[0]);
      return frame[0].src = "pkg://libpdfjs/web/viewer.html".asFileHandle().getlink() + "?file=" + this.currfile.getlink();
    }

    renderSVG() {
      $(this.find("statcontainer")).show();
      this.trigger("resize");
      ($(this.view)).attr("class", "image");
      return this.currfile.read().then((d) => {
        this.view.innerHTML = d;
        return $($(this.view).children()[0]).css("width", "100%").css("height", "100%");
      }).catch((e) => {
        return this.error(__("Unable to read file: {0}", this.currfile.path), e);
      });
    }

    renderImage() {
      $(this.find("statcontainer")).show();
      this.trigger("resize");
      ($(this.view)).attr("class", "image");
      return this.currfile.read("binary").then((d) => {
        var blob, canvas, img;
        img = new Image();
        canvas = ($("<canvas/>"))[0];
        ($(this.view)).append(canvas);
        //($ me.view).append img
        img.onload = () => {
          var context;
          context = canvas.getContext('2d');
          canvas.height = img.height;
          canvas.width = img.width;
          this.img = img;
          //console.log canvas.width, canvas.height
          context.drawImage(img, 0, 0);
          return this.setStatus(`${this.currfile.info.size} Kb - ${img.width}x${img.height}`);
        };
        blob = new Blob([d], {
          type: this.currfile.info.mime
        });
        return img.src = URL.createObjectURL(blob);
      }).catch((e) => {
        return this.error(__("Unable to read file: {0}", this.currfile.path), e);
      });
    }

    menu() {
      var menu;
      menu = [
        {
          text: "__(File)",
          nodes: [
            {
              text: "__(Open)",
              dataid: `${this.name}-Open`,
              shortcut: "A-O"
            },
            {
              text: "__(Close)",
              dataid: `${this.name}-Close`,
              shortcut: "C-X"
            }
          ],
          onchildselect: (e) => {
            return this.actionFile(e.data.item.data.dataid);
          }
        }
      ];
      return menu;
    }

    actionFile(e) {
      switch (e) {
        case `${this.name}-Open`:
          return this.openDialog("FileDialog", {
            title: __("Open file"),
            mimes: this.meta().mimes
          }).then((d) => {
            return this.open(d.file.path.asFileHandle());
          });
        case `${this.name}-Close`:
          return this.quit();
      }
    }

  };

  this.OS.register("Preview", Preview);

}).call(this);
