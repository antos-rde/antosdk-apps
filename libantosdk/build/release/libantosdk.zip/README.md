# libantosdk
AntOSDK: development API for AntOS based applications/projects

## Change logs
- 0.0.11: Update AntOS API v1.2.1
- 0.0.10: fix binary readfile bug
- 0.0.9: Fix locale gen bug
- 0.0.8: Update JQuery support in typescript
- 0.0.7: enable typescript downlevelIteration compile option
- 0.0.6: add GUI application for building a JSON build file
- 0.0.5: add API that supports running Linux commands on server
- 0.0.4: support automatic locale generation