# libantosdk
AntOSDK: development API for AntOS based applications/projects

## Change logs
- 0.0.4: support automatic locale generation