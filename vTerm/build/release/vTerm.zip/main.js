(function() {
  // Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>

  // AnTOS Web desktop is is licensed under the GNU General Public
  // License v3.0, see the LICENCE file for more information

  // This program is free software: you can redistribute it and/or
  // modify it under the terms of the GNU General Public License as
  // published by the Free Software Foundation, either version 3 of 
  // the License, or (at your option) any later version.

  // This program is distributed in the hope that it will be useful,
  // but WITHOUT ANY WARRANTY; without even the implied warranty of
  // MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  // General Public License for more details.

  // You should have received a copy of the GNU General Public License
  //along with this program. If not, see https://www.gnu.org/licenses/
  var vTerm;

  vTerm = class vTerm extends this.OS.application.BaseApplication {
    constructor(args) {
      super("vTerm", args);
    }

    main() {
      var checklib;
      this.mterm = this.find("myterm");
      this.term = new Terminal({
        cursorBlink: true
      });
      this.fitAddon = new FitAddon.FitAddon();
      this.term.loadAddon(this.fitAddon);
      this.term.setOption('fontSize', '12');
      this.term.open(this.mterm);
      this.sub = void 0;
      this.bindKey("CTRL-SHIFT-C", (e) => {
        this.mctxHandle({
          id: "copy"
        });
        return this.term.focus();
      });
      this.bindKey("CTRL-SHIFT-V", (e) => {
        return this.mctxHandle({
          id: "paste"
        });
      });
      this.term.onKey((d) => {
        if (!this.sub) {
          return;
        }
        return this.sub.send(Antunnel.Msg.DATA, new TextEncoder("utf-8").encode(d.key));
      });
      this.on("focus", () => {
        return this.term.focus();
      });
      this.mterm.contextmenuHandle = (e, m) => {
        m.items = [
          {
            text: "__(Copy)",
            id: "copy"
          },
          {
            text: "__(Paste)",
            id: "paste"
          }
        ];
        m.onmenuselect = (e) => {
          if (!e) {
            return;
          }
          return this.mctxHandle(e.data.item.data);
        };
        return m.show(e);
      };
      this.resizeContent();
      if (!this.systemsetting.desktop.menu[this.name]) {
        // make desktop menu if not exist
        this.systemsetting.desktop.menu[this.name] = {
          text: "__(Open terminal)",
          app: "vTerm"
        };
      }
      this.on("hboxchange", (e) => {
        return this.resizeContent();
      });
      checklib = () => {
        if (!Antunnel.tunnel) {
          return this._gui.pushService("Antunnel/AntunnelService").then((d) => {
            if (!this.systemsetting.system.tunnel_uri) {
              return;
            }
            return Antunnel.init(this.systemsetting.system.tunnel_uri).then((t) => {
              this.notify(__("Tunnel now connected to the server at: {0}", this.systemsetting.system.tunnel_uri));
              this.tunnel = Antunnel.tunnel;
              return this.openSession();
            }).catch((e) => {
              if (Antunnel.tunnel) {
                Antunnel.tunnel.close();
              }
              this.error(__("Unable to connect to the tunnel: {0}", e.toString()), e);
              return this.quit();
            });
          }).catch((e) => {
            this.error(__("Unable to run Antunnel service: {0}", e.toString()), e);
            return this.quit();
          });
        } else {
          this.tunnel = Antunnel.tunnel;
          return this.openSession();
        }
      };
      if (!window.Antunnel) {
        return this._api.requires("pkg://Antunnel/main.js").then(() => {
          return checklib();
        }).catch((e) => {
          this.error(__("Unable to load Antunnel: {0}", e.toString()), e);
          return this.quit();
        });
      } else {
        return checklib();
      }
    }

    mctxHandle(data) {
      var cb, text;
      switch (data.id) {
        case "paste":
          cb = (text) => {
            if (!(text && text !== "")) {
              return;
            }
            text = text.replace(/\n/g, "\r");
            if (this.sub) {
              this.sub.send(Antunnel.Msg.DATA, new TextEncoder("utf-8").encode(text));
            }
            return this.term.focus();
          };
          return this._api.getClipboard().then((text) => {
            return cb(text);
          }).catch((e) => {
            this.error(__("Unable to paste"), e);
            //ask for user to enter the text manually
            return this.openDialog("TextDialog", {
              title: "Paste text"
            }).then((text) => {
              return cb(text);
            }).catch((err) => {
              return this.error(err.toString(), err);
            });
          });
        case "copy":
          text = this.term.getSelection();
          if (!(text && text !== "")) {
            return;
          }
          return this._api.setClipboard(text);
      }
    }

    resizeContent() {
      var arr, ncol, nrow;
      this.fitAddon.fit();
      ncol = this.term.cols;
      nrow = this.term.rows;
      if (!this.sub) {
        return;
      }
      arr = new Uint8Array(8);
      arr.set(Antunnel.Msg.bytes_of(ncol), 0);
      arr.set(Antunnel.Msg.bytes_of(nrow), 4);
      return this.sub.send(Antunnel.Msg.CTRL, arr);
    }

    openSession() {
      this.term.clear();
      this.term.focus();
      this.sub = new Antunnel.Subscriber("vterm");
      this.sub.onopen = () => {
        console.log("Subscribed");
        this.resizeContent(($(this.mterm)).width(), ($(this.mterm)).height());
        return this.term.focus();
      };
      this.sub.onerror = (e) => {
        this.error(__("Unable to connect to: vterm"), e);
        return this.sub = void 0;
      };
      this.sub.onmessage = (e) => {
        if (this.term && e.data) {
          return this.term.write(new TextDecoder("utf-8").decode(e.data));
        }
      };
      this.sub.onclose = () => {
        this.sub = void 0;
        this.notify(__("Terminal connection closed"));
        return this.quit();
      };
      return this.tunnel.subscribe(this.sub);
    }

    cleanup(e) {
      if (this.sub) {
        return this.sub.close();
      }
    }

  };

  vTerm.dependencies = ["pkg://xTerm/main.js", "pkg://xTerm/main.css", "pkg://Antunnel/main.js"];

  this.OS.register("vTerm", vTerm);

}).call(this);
