# Booklet
A back-end tool for my online document hub [https://doc.iohub.dev/antos/](https://doc.iohub.dev/antos/)


## Change logs

### v0.1.0-a
* Add support to model/gltf-binary file
### v0.1.0-a: new feature
* Entries of the same parent now can go up and down
* Support drag and drop to move entries around
* Support assets such as image files can be uploaded and stored directly into the book structure
* Booklet can now render local image

### v0.0.3-a
* Clean up code

### v0.0.2-a
* First public release
*