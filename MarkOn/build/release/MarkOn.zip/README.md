# MarkOn markdown editor

Simple Markdown editor for antOS

## Change log
- 0.1.1-a: Fix window resize bug
- 0.1.0-a: Use the new EasyMDE library