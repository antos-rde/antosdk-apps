# libthreejs

AntOS package wrapper for the famous Three.js library R129.

## About Three.js

The aim of the project is to create an easy to use, lightweight,
cross-browser, general purpose 3D library. The current builds only
include a WebGL renderer but WebGPU (experimental), SVG and CSS3D
renderers are also available in the examples.

Github: [https://github.com/mrdoob/three.js](https://github.com/mrdoob/three.js)