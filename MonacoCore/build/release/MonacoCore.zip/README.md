# MonacoCore
The Monaco Editor is the code editor which powers VS Code.

This library is the AntOS package wrapper of the Monaco editor 0.23.0

For more information on the editor: [https://microsoft.github.io/monaco-editor/](https://microsoft.github.io/monaco-editor/)