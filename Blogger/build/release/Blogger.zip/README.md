# Blogger

Blackend for my blog at https://blog.iohub.dev


## Change logs

### v0.2.x-a
* Patch 6: Chage libraries load order
* Patch 5: Add user photo to portfolio
* Patch 4: Add package dependencies
* Patch 3: Correct JSON text decoding
* Patch 2: Bug fix rendering content
* Patch 0-1 Important change: Store raw post content to the database instead of base64 string as before

### v0.1.x-a
* Patch 3-4: Enhance youtube video embedding feature in markdown
* Patch 2: CV Category now can be created when database is not created yet
* Patch 1: Fix package archive broken
* Patch 0: Change default email of the sender