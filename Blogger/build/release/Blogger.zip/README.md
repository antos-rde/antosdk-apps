# Blogger

Blackend for my blog at https://blog.iohub.dev


## Change logs

### v0.2.2-a
* patch 2: Bug fix rendering content
* patch 0-1 Important change: Store raw post content to the database instead of base64 string as before

### v0.1.4-a
* Minor bug fix
* Enhance youtube video embedding feature in markdown

### v0.1.2-a
* Minor bug fix
* CV Category now can be created when database is not created yet

### v0.1.1-a
* Minor bug fix
* Fix package archive broken

### v0.1.0-a
* Minor bug fix
* Change default email of the sender