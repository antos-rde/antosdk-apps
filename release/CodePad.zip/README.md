# CodePad
A simple yet powerful code/text editor.
CodePad is a text editor based on the ACE editor.

## Change logs
- v0.1.7-a: fix setting bug using new AntOS setting API
- v0.1.6-a: adapt to new AntOS v2.0.x
- v0.1.5-a: CodePad moved out of AntOS based system as regular AntOS package