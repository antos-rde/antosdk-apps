# vfsx
AntOS VFS handles for various file protocols which are not included by default
int core release, such as:
- GoogleDrive
- Dropbox (TODO)

This package is used mainly by the File application to communicate with different
file hosting protocols

## Change logs
* v0.1.1-b Use new Task API for tracking task
