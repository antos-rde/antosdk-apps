# Docify
Simple PDF document manager

## Change logs
- v0.1.1-b: move PDF merge and document thumbnail generation to client side, remove server side lua script
- v0.1.0-b: use libsqlite for database handling
- v0.0.9-b: Adapt to support AntOS 2.0.x
- v0.0.8-b: Allow upload files directly from the app
- v0.0.7-a: Change category and icon
- v0.0.6-a: Add print dialog (support server side printing)
- v0.0.5-a: Fix delete file bug
- v0.0.4-a: Display file size in entry meta-data
- v0.0.3-a: Fix document moved bug, sort entries by year, month, day