# SVGEdit

AntOS bundle for the SVGEdit at https://github.com/SVG-Edit/svgedit

This package bundles the version 7.2.0 of the SVGEdit

