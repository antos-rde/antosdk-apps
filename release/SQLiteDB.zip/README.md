# SQLiteDB

This package contains the SQLiteDB API binding for AntOS applications
and a simple sqlite3 browser application that uses the library as reference

Note: in AntOS, file with extension `.db` is considered as sqlite3 database
file and has the following mimetype `application/vnd.sqlite3`. Applications
shall use this mime in `package.json`

## Change logs
- v0.1.0a: initial version with functioning library binding
