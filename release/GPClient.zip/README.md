# GPClient

Simple Multi purpose client wrapper

## change logs
- allow clipboard read/write in iframe
