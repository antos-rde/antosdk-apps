# Server log monitor
This application allows to monitor Server Syslog
using Antunnel protocol. Features:
* Realtime log monitoring
* Filter logs by pattern (regular expression), severity
* Recording last n log messages

## Change logs
* v0.1.1-b minor fix on dialog handling, fix incorrect package version
* v0.1.0-b first beta version