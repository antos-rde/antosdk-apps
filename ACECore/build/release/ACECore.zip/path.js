
ace.config.set("basePath", "pkg://ACECore/core".asFileHandle().getlink());
ace.require("ace/ext/language_tools");
