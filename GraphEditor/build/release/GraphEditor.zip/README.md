# GraphEditor

Generate graph from text using mermaid

## Change logs

* v0.0.8-a: Fix ace path
* v0.0.7-a: Fix worker path
* v0.0.6-a: Fix unable to export image from tainted canvas
* v0.0.5-a: GraphEditor is now compatible with new AntOS API


Note: This application use the open source library [Mermaid js](https://mermaid-js.github.io/mermaid) for graph rendering