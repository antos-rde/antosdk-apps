# Docify
Simple PDF document manager

## Change logs
- v0.0.5-a: Fix delete file bug
- v0.0.4-a: Display file size in entry meta-data
- v0.0.3-a: Fix document moved bug, sort entries by year, month, day