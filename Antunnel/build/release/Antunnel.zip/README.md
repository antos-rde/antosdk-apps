# Antunnel

`Antunnel` is a client side API that allows AntOS applications to
talk to server side applications via the [`antd-tunnel-pligin`](https://github.com/lxsang/antd-tunnel-plugin) plugin
using a single websocket API.
