# Antunnel

`Antunnel` is a client side API that allows AntOS applications to
talk to server side applications via the [`antd-tunnel-pligin`](https://github.com/lxsang/antd-tunnel-plugin) plugin
using a single websocket API.

## Changes log
- v0.1.4-a Reduce frame overhead
- v0.1.3-a Remove magic number in the frame to reduce frame overhead
