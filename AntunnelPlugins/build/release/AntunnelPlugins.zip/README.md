# Antunnel Plugins
Aditional Plugins for Antunnel library.
This package provides also the Typescript declaration file for
application Development.

## Change logs
- v.0.1.2: minor changes on API
- v.0.1.1: Added group query support
- v.0.1.0: Antunnel API declaration and broadcast plugin