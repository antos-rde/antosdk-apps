# libjpeg
Simple JPEG/DCT data decoder in JavaScript. Also this project includes JPEG 2000 and JBIG2 decoders.

Github page: [https://github.com/notmasteryet/jpgjs](https://github.com/notmasteryet/jpgjs)