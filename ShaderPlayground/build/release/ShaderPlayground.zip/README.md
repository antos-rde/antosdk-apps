# ShaderPlayground

Playground for working with Open GL shader language, the sharder is rendered
with the Three.js library

## Change logs
- v0.0.3-a: reset texture when open new file
- v0.0.2-a:
    - Remove GLSLX, use the default WEBGL API for shader compiling
    - Allow save/open shader source code to/from file (JSON)
- v0.0.1-a: Initial version