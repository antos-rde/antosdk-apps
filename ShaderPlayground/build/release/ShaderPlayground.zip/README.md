# ShaderPlayground

Playground for working with Open GL shader language, the sharder is rendered
with the Three.js library

## Change logs
- v0.0.1-a: Initial version