# IOMail

Simple Mail client wrapper for https://mail.iohub.dev/
