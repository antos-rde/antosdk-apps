# GPClient

Simple Multi purpose client wrapper
