# TinyEditor
This is the example project for the tutorial: [https://blog.lxsang.me/post/id/20](https://blog.lxsang.me/post/id/20). The tutorial is outdated, it is no longer compatible with the new antos API

