# Antedit
Simple yet powerful text/code editor based on the Monaco editor,
the editor that powers VS Code.

The editor functionality can be extended by its extension mechanism.
Extension can be developed/released/isntalled by the editor itself.

### Change logs
- 0.1.12-b: fix recent files not adding correctly
- 0.1.11-b: fix file type parsing from path
- 0.1.10-b: Antedit now has it own extension manager
- 0.1.9-a: Allow output text selection
- 0.1.8-a: Allow to change language mode
- 0.1.7-a: Add keyboard shortcut support to extension actions