# SystemControl

System monitoring is a part of my ROS Based robot software system.

It allows to display the robot resource infomation (such as battery, network, CPU load, memory load, etc.) on Antos application
via the Antunnel service

![https://raw.githubusercontent.com/lxsang/antosdk-apps/master/SystemControl/screenshot.png](https://raw.githubusercontent.com/lxsang/antosdk-apps/master/SystemControl/screenshot.png)

