# SystemControl

System monitoring is a part of my ROS Based robot software system.

It allows to dislay the robot system info mation on Antos application
via the Antunnel service


