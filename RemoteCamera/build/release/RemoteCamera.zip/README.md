# RemoteCamera

Connect to a V4L2 camera on server via Antunnel plugin.

![](https://raw.githubusercontent.com/lxsang/antosdk-apps/master/RemoteCamera/screenshot.jpg)

This application reauires the **tunel plugin** and the **ant-tunnel v4l2 publisher**
on the server-side

## Change log
* v0.1.5-a: support AntOS 2.0.x
* v0.1.4-a: change app category
* v0.1.2-a: user worker for jpeg decoding
