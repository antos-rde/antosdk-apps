# RemoteCamera

Connect to a V4L2 camera on server via Antunnel.

This application reauires the **tunel plugin** and the **ant-tunnel v4l2 publisher**
on the server-side