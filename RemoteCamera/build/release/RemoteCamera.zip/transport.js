let decoder = new Worker("decoder.js");
let queue = [];
let processing = false;


decoder.onmessage = (e) =>
{
    let msg = e.data;
    postMessage(msg, [msg.pixels]);
    if(queue.length > 0)
    {
        let task = queue.shift();
        decoder.postMessage(task,[task.data]);
        processing = true;
    }
    else
    {
        processing = false;
    }
}

onmessage = (e) => {
    switch (e.data.cmd) {
        case 0x0:
            decoder.postMessage(e.data);
            break;
        case 0x1:
            console.log("queue size is " + queue.length);
            if(processing)
            {
                queue.push(e.data);
            }
            else
            {
                let task = e.data;
                decoder.postMessage(task,[task.data]);
                processing = true;
            }
            break;
        default:
            console.error("Unknown command " + e.data.cmd);
    }
}
