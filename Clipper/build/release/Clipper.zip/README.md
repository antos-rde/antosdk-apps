# Clipper

VDE screen capture tool.

Clipper use `html2canvas` to capture AntOS desktop or a specific window.
It is able to crop the captured image before saving to a file

## Change logs
* v0.1.3-a change app category
* v0.1.2-a use ALT-S as global shortcut for screen capture
* v0.1.1-a use CTRL-S as global shortcut for screen capture
* v0.1.0-a initial version


## Credit
* [html2canvas](https://html2canvas.hertzen.com/)