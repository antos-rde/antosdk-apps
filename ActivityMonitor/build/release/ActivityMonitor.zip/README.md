# Activity monitor

This simple application show the current running AntOS processes

## Change logs
### v0.0.8-b
* Increase default window size

### v0.0.6-a
* Fix process type identification bug

### v0.0.5-a
* Fix process type identification bug