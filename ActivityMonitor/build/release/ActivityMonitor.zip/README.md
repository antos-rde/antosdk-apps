# Activity monitor

This simple application show the current running AntOS processes

## Change logs

### v0.0.5-a
* Fix process type identification bug