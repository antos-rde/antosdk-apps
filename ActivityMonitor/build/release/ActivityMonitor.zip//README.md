# Activity monitor

This simple application show the current running AntOS processes