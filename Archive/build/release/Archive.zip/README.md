# Archive

Small application for zip file manager

## Features
* Open, create zip file Archive
* Add/remove file/folder to archive
* Extract zip file content

## Changle log

### v0.0.4-a
* Fix file dialog bug when extract zip content

### v0.0.3-a
* Change category to utility

### v0.0.2-a
* Adapt to the new AntOS string API

### v0.0.1-a
* First release