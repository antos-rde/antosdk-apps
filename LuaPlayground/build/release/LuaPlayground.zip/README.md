#LuaPlayground


Application for serverside code testing and analytics tool.
It allows to execute lua code on the server from the browser

## Change logs
* 0.0.6-a: Fix ace path error
* 0.0.5-a: Fix worker path error