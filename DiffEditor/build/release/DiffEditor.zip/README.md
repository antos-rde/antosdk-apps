# DiffEditor
View and edit files in diff mode

## Change logs
- 0.1.6-a: adapt to new AntOS v2.0.x
- Add dependencies
