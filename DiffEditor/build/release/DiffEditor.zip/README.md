# DiffEditor
View and edit files in diff mode

## Change logs
- Add dependencies
