# GraphEditor

Generate graph from text using dot(viz) format

## Change logs
* v0.0.2-a: Fix path problem
* v0.0.1-a: First version