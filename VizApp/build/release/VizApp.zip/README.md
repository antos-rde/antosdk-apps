# GraphEditor

Generate graph from text using dot(viz) format

## Change logs
* v0.1.0-a: Add package dependencies
* v0.0.2-a: Fix path problem
* v0.0.1-a: First version