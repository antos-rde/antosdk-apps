# GraphEditor

Generate graph from text using dot(viz) format

## Change logs

### v0.0.1-a
* First version