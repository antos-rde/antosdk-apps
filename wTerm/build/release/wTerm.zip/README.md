# AntOS Terminal

Terminal emulator to connect to remote server using AntOS websocket connection