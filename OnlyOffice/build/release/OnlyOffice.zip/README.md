# OnlyOffice

This application is the front-end connector of the OnlyOffice suite.
It needs to connect to a working OnlyOffice document server.

The application allows to open/edit document, presentation, and spreedsheet

