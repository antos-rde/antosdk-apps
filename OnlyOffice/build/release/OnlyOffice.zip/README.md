# OnlyOffice

This application is the front-end connector of the OnlyOffice suite.
It needs to connect to a working OnlyOffice document server.

The application allows to open/edit commons document, presentation, and spreedsheet.
Integrate OnlyOffice to an virtual window environment like AntOs allows an inconvenient
way to work with multiple document at the same time


